I got cought in an unfortunate situation, and I had to use all my 3 late days on an assignment as easy as this one.
I could have implemented a better detector that would take care of the scaling issues, but right now I would like to move to project 3 in order to avoid a snow ball effect on completing assigments for this class and artificial intelligence

