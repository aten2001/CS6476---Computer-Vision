I try to put images side by side so that it would be easy to compare, but doing that make them too small, and it's hard to see the red dots. Thus, I have stacked them on top of each other.

For each pair of images, I present the epipolar lines found using the fundamental matrix obtained from unnormalized coordinates followed by the one found using the fundamental matrix obtained form normalized coordinates.

